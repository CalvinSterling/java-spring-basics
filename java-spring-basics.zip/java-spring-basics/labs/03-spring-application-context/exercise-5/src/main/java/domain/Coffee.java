package domain;

public class Coffee extends Ingredient {

    public Coffee(long id, String name) {
        super(id, name);
    }
}
