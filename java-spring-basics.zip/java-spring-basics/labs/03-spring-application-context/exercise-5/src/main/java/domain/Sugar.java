package domain;

public class Sugar extends Ingredient {

    public Sugar(long id, String name) {
        super(id, name);
    }
}
